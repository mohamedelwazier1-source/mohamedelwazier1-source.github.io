# HellHounds Women Flag Football 2027 — Online Shared Version

This version keeps the original HTML practice planner and its interactive behavior. The old Claude-only collaboration connection has been replaced with Firebase Realtime Database + Anonymous Authentication so multiple people can open the same web page and see changes live.

## What is preserved

- Same title and team/practice content
- Same practice-plan layout and styling
- Coaches and players
- Attendance and absence reasons
- Practice theme / comments
- Equipment checklist
- Practice review fields
- Drill rows, timing, focus areas, descriptions, equipment and lead coaches
- Parallel/same-time drills
- Automatic timing calculation
- New / Clear all behavior
- Live status indicator

## Step 1 — Create the Firebase project

1. Open https://console.firebase.google.com/
2. Create a new Firebase project, for example `hellhounds-women-2027`.
3. Add a Web App to the project.
4. Copy the Firebase Web App configuration.

## Step 2 — Enable anonymous login

In Firebase Console:

Authentication → Sign-in method → Anonymous → Enable.

The site uses anonymous authentication so coaches do not need to create accounts. This means anyone who has the shared website link can edit the shared plan.

## Step 3 — Create the shared database

Firebase Console → Build → Realtime Database → Create Database.

Choose a database location and create it.

Then open the Rules tab and paste the contents of `database.rules.json`.

The supplied rules mean authenticated users can read and write the practice data. Because this app uses anonymous authentication, this is effectively “anyone with the website link can edit.”

## Step 4 — Put your Firebase config into index.html

Open `index.html` and find:

```js
const FIREBASE_CONFIG = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://PASTE_YOUR_DATABASE_NAME-default-rtdb.firebaseio.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};
```

Replace those values with the configuration Firebase gives you.

## Step 5 — Publish it online

### GitHub Pages option

1. Create a GitHub repository.
2. Upload `index.html`.
3. Commit the file.
4. Repository → Settings → Pages.
5. Choose the branch containing `index.html` and the root folder.
6. Save.
7. GitHub will provide the public website address.

Share that address with the coaches.

### Important

GitHub Pages hosts the HTML/CSS/JavaScript, while Firebase stores and synchronizes the practice data. GitHub Pages does not itself provide the shared database.

## How the sharing works

All coaches open the same website URL. Each browser signs in anonymously to Firebase and connects to the same database path:

`practice/main`

and

`practice/rows`

When one person changes a field or drill, Firebase sends the change to the other connected browsers in real time.

## Security note

The current setup intentionally allows every authenticated visitor to edit because the requested behavior is shared editing for the team. If you later want the page visible to everyone but editable only by HellHounds coaches, change this to Google/email authentication and restrict the database rules.
